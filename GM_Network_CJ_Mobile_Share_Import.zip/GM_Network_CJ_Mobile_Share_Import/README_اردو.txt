GM NETWORK — CJ MOBILE SHARE IMPORT (NO EXTENSION)

اس پیکج سے Android پر CJ پروڈکٹ پیج کا لنک Share کرکے GM Network میں امپورٹ کیا جا سکے گا۔ Extension یا Kiwi کی ضرورت نہیں ہوگی۔

اہم: پہلے اپنے GitHub repository کے root میں یہ فائلیں اپلوڈ/Replace کریں:
1) index.html (پرانا index.html replace کریں)
2) manifest.webmanifest
3) sw.js
4) icons فولڈر (اس کے اندر دونوں PNG icons سمیت)

اس کے بعد GitHub Pages کو اپڈیٹ ہونے دیں۔ موبائل Chrome میں GM Network ویب سائٹ کھولیں، مینو سے Install app یا Add to Home screen کریں۔ اگر پرانی GM Network shortcut پہلے سے نصب ہے تو اسے ہٹا کر نئی اپڈیٹ کے بعد دوبارہ Install کرنا پڑ سکتا ہے تاکہ Share target ظاہر ہو۔

استعمال: CJ پر کوئی پروڈکٹ کھولیں > Share > Android share sheet میں GM Network منتخب کریں۔ GM Network کھلے گا؛ ایڈمن سائن اِن ہو تو امپورٹ فارم سامنے آجائے گا۔ ایڈمن سائن اِن نہ ہو تو پہلے سائن اِن کریں؛ پھر اسی CJ لنک کو دوبارہ Share کریں۔

یہ صرف پروڈکٹ کی تفصیلات GM Network میں Draft کے طور پر امپورٹ کرتا ہے۔ آرڈر، ادائیگی، شپنگ، fulfillment اور tracking اس مرحلے میں شامل نہیں۔ CJ API Key یا tokens اس پیکج میں موجود نہیں۔
